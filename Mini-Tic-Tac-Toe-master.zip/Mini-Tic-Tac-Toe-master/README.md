#MINI TIC TAC TOE


Unbeatable mini Tic Tac Toe based on min-max algorithm of game theory. The AI of this Tic Tac Toe always ensures the fastest possible victory. 

#How To Run :
 
Install latest g++ compiller on your UNIX system.

Download the main.cpp file which conatins the code.

Now,
	g++ main.cpp -Wall

*Ignore the Warnings

An interface will open on the terminal 
Enter you name : Example

_ _ _ | (1,1)(1,2)(1,3)

_ _ _ | (1,1)(1,2)(1,3)

_ _ _ | (1,1)(1,2)(1,3)

To make a move enter the corresponding coordinate from right side.
for example if you enter 1 2

Your board will turn to this and bot will play its move and the so on...

_ E _ | (1,1)(1,2)(1,3)

_ _ _ | (1,1)(1,2)(1,3)

_ _ _ | (1,1)(1,2)(1,3)


reference : www.geeksforgeeks.com


